# Changelog

## [1.0.1] - 2021-06-15

### Changes
- Added the Code Coverage package

## [1.0.0] - 2021-04-23

### This is the first release of *Engineering* feature set.
